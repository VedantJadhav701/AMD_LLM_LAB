# AMD LLM Lab

Test. Predict. Optimize. Deploy.

## Purpose

AMD LLM Lab is an LLM inference benchmarking and prediction
platform focused initially on AMD Instinct MI300X.

It benchmarks:

- Model size
- Precision
- Quantization
- Backend
- Context length
- VRAM consumption
- Generation throughput

It provides:

- VRAM prediction
- Throughput prediction
- Prediction uncertainty
- Configuration feasibility filtering
- Configuration recommendation

## Current Hardware

GPU:
AMD Instinct MI300X

VRAM:
192 GB

Architecture:
gfx942:sramecc+:xnack-

## Current Dataset

57 benchmark configurations.

Model sizes:

0.5B
1.544B
3.086B
7.615B
14.77B
32.76B

Precisions:

BF16
FP16
INT2
INT4
INT8

Contexts:

512
1024
2048
4096
8192

## Prediction Models

### VRAM

Current production baseline:

Linear Regression

Input:
parameters_b

Target:
peak_vram_gb

Validation:
Leave-One-Model-Out

### Throughput

Current production model:

ExtraTreesRegressor

Inputs:

parameters_b
context_tokens
precision
quantization
backend

Target:

generation_tok_s

Validation:
Leave-One-Model-Out

## Validation Results

Throughput:

MAE: approximately 12.01 tok/s
R2: approximately 0.657

VRAM:

MAE: approximately 6.75 GB
R2: approximately 0.536

## Important Limitations

1. Current benchmark data is from MI300X only.
2. Predictions outside the observed model-size range have
   lower reliability.
3. VRAM prediction is currently primarily size-based.
4. Throughput is configuration-aware.
5. Predictions should not be treated as direct measurements.
6. Real inference benchmarking should validate important
   deployment decisions.

## Recommendation Engine

The recommendation engine:

1. Generates available configurations.
2. Predicts VRAM and throughput.
3. Applies VRAM constraints.
4. Applies minimum throughput constraints.
5. Ranks feasible configurations according to:
   - throughput
   - memory
   - balanced objective

## Project Structure

data/
models/
evaluation/
config/
notebooks/

## Next Development Phase

- Local inference API
- Web dashboard
- CLI
- More AMD GPU benchmarks
- More model architectures
- More backend implementations
- Configuration-specific VRAM modeling
- Improved uncertainty estimation